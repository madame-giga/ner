import pykube, kopf

VERSION = "spec.io/v1alpha1"
KIND = "MyAgent"

def create_kubernetes_client():
    kube_config = pykube.config.KubeConfig.from_env()
    kube_client = pykube.HTTPClient(kube_config)
    return kube_client
   
   
def get_kubernetes_objects(kube_client):
    MyAgent = pykube.object_factory(kube_client, VERSION, KIND)
    return MyAgent.objects(kube_client, namespace=pykube.all).iterator()
    

def generate_agent_config(agent_name, agent_pod_tolerance):
    config = {
      "apiVersion": "apps/v1",
      "kind": "Deployment",
      "metadata": {
        "name": f"nginx-{agent_name}-{agent_pod_tolerance}"
      },
      "spec": {
        "replicas": 3,
        "selector": {
          "matchLabels": {
            "app": f"nginx-{agent_name}-{agent_pod_tolerance}"
          }
        },
        "template": {
          "metadata": {
            "labels": {
              "app": f"nginx-{agent_name}-{agent_pod_tolerance}"
            }
          },
          "spec": {
            "containers": [
              {
                "name": f"nginx-{agent_name}-{agent_pod_tolerance}-container",
                "image": "nginx:latest",
                "ports": [
                  {
                    "containerPort": 80
                  }
                ]
              }
            ]
          }
        }
      }
    }
    return config
    
  
def deploy_object(kube_client, object_config):
    deployment = pykube.Deployment(kube_client, object_config)
    kopf.adopt(deployment)
    deployment.create()


def deploy_agents():
    kube_client = create_kubernetes_client()
    agents = get_kubernetes_objects(kube_client)
    for agent in agents:
        agent_name = str(agent)
        agent_pod_tolerance = agent.obj['spec']['podTolerance']
        config = generate_agent_config(agent_name, agent_pod_tolerance)
        print(config)
        #deploy_object(kube_client, config)


    
@kopf.on.create('myagents')
def create_fn(spec, **kwargs):
    kube_client = create_kubernetes_client()      
    object_config = generate_agent_config(spec['name'], spec['podTolerance'])  
    deploy_object(kube_client, object_config)
    return {"message": f"Deployment for {spec['name']} created"}


print()    
