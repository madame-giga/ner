package org.example;
import com.uber.h3core.H3Core;
import com.fasterxml.jackson.core.*;
import java.io.*;
import java.util.*;

public class SpatioTemporalJsonEnricher extends Thread {

    private String inputFilePath;
    private String outputFilePath;
    private String latKey;
    private String lngKey;

    public SpatioTemporalJsonEnricher(String inputFilePath, String outputFilePath, String latKey, String lngKey) {
        this.inputFilePath = inputFilePath;
        this.outputFilePath = outputFilePath;
        this.latKey = latKey;
        this.lngKey = lngKey;
    }

    public void run() {
        File inputFile = new File(inputFilePath);
        File outputFile = new File(outputFilePath);

        H3Core h3 = null;
        try {
            h3 = H3Core.newInstance();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        int[] resolutions = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

        JsonFactory factory = new JsonFactory();
        try (
                JsonParser parser = factory.createParser(inputFile);
                JsonGenerator generator = factory.createGenerator(outputFile, JsonEncoding.UTF8)
        ) {
            // Start array
            parser.nextToken(); // START_ARRAY
            generator.writeStartArray();

            while (parser.nextToken() == JsonToken.START_OBJECT) {
                Map<String, Object> obj = new HashMap<>();
                Double lat = null, lon = null;

                // Read fields of the object
                while (parser.nextToken() != JsonToken.END_OBJECT) {
                    String fieldName = parser.getCurrentName();
                    parser.nextToken();
                    if (latKey.equals(fieldName)) {
                        lat = parser.getValueAsDouble();
                        obj.put(fieldName, lat);
                    } else if (lngKey.equals(fieldName)) {
                        lon = parser.getValueAsDouble();
                        obj.put(fieldName, lon);
                    } else {
                        obj.put(fieldName, parser.getValueAsString());
                    }
                }

                // Compute H3 cells for all resolutions
                Map<String, String> h3Cells = new HashMap<>();
                if (lat != null && lon != null) {
                    for (int res : resolutions) {
                        h3Cells.put("h3_res_"+res, h3.latLngToCellAddress(lat, lon, res));
                    }
                }

                // Write object with new field
                generator.writeStartObject();
                for (Map.Entry<String, Object> entry : obj.entrySet()) {
                    generator.writeObjectField(entry.getKey(), entry.getValue());
                }
                generator.writeFieldName("h3_cells");
                generator.writeStartObject();
                for (Map.Entry<String, String> entry: h3Cells.entrySet()) {
                    generator.writeObjectField(entry.getKey(), entry.getValue());
                }
                generator.writeEndObject();
                generator.writeEndObject();
            }

            generator.writeEndArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
