package org.example;

import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws Exception {

        System.out.println("splitting file...");
        CsvSplitter splitter = new CsvSplitter();
        ArrayList<String> splitFiles = splitter.splitCsvWithHeader(args[0], 100000);
        for (String split : splitFiles) {
            System.out.println("Converting CSV to JSON: " + split);
            CsvConverter converter = new CsvConverter(split, split + ".json");
            converter.start();
        }

        System.out.println("Enriching JSON...");
        long start = System.currentTimeMillis();
        SpatioTemporalJsonEnricher jsonEnricher = new SpatioTemporalJsonEnricher();
        jsonEnricher.start();
        long finish = System.currentTimeMillis();
        long timeElapsed = finish - start;
        System.out.println(timeElapsed);
    }
}