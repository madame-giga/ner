package org.example;

import java.io.*;
import java.util.ArrayList;

public class CsvSplitter {
    public ArrayList<String> splitCsvWithHeader(String inputFile, int linesPerChunk) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        String header = reader.readLine();
        if (header == null) {
            reader.close();
            return null; // Empty file
        }

        ArrayList<String> outfiles = new ArrayList<>();
        int fileIndex = 1;
        int lineCount = 0;
        String outfile = getChunkFileName(inputFile, fileIndex);
        outfiles.add(outfile);
        System.out.println("Writing splitted file " + outfile);
        PrintWriter writer = new PrintWriter(outfile);
        writer.println(header);

        String line;
        while ((line = reader.readLine()) != null) {
            if (lineCount >= linesPerChunk) {
                writer.close();
                fileIndex++;
                outfile = getChunkFileName(inputFile, fileIndex);
                System.out.println("Writing splitted file " + outfile);
                outfiles.add(outfile);
                writer = new PrintWriter(new FileWriter(outfile));
                writer.println(header);
                lineCount = 0;
            }
            writer.println(line);
            lineCount++;
        }
        writer.close();
        reader.close();
        return outfiles;
    }

    private String getChunkFileName(String base, int index) {
        return base.replace(".csv", "") + "_part" + index + ".csv";
    }
}
