# suppress warnings for notebook
import warnings
warnings.filterwarnings("ignore")
# download nltk 'punkt' in order to use nltk word/sent-tokenize
import nltk
nltk.download('punkt')