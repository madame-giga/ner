package org.example;
import java.io.File;
import com.fasterxml.jackson.core.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class CsvConverter extends Thread {

    private String csvFile;
    private String jsonFile;

    public CsvConverter(String csvFile, String jsonFile) {
        this.csvFile = csvFile;
        this.jsonFile = jsonFile;
    }

    public void run() {
        System.out.println("Converting file " + this.csvFile);
        try (
                BufferedReader br = new BufferedReader(new FileReader(csvFile, StandardCharsets.UTF_8));
                JsonGenerator jGenerator = new JsonFactory().createGenerator(new File(jsonFile), JsonEncoding.UTF8)
        ) {
            String headerLine = br.readLine();
            if (headerLine == null) return;
            String[] headers = headerLine.split(",");

            jGenerator.writeStartArray();

            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                jGenerator.writeStartObject();
                for (int i = 0; i < headers.length && i < values.length; i++) {
                    jGenerator.writeStringField(headers[i], values[i]);
                }
                jGenerator.writeEndObject();
            }

            jGenerator.writeEndArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

