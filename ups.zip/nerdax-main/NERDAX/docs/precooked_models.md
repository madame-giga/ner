# Precooked NERDA models
::: NERDA.precooked